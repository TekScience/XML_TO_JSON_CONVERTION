﻿<?php
///////////////////////////////////////////////////////////////////////////

require_once 'lib/hashed_array.php';
require_once 'lib/tv/abstract_tv.php';
require_once 'lib/tv/default_epg_item.php';
require_once 'fox_setup_screen.php';
require_once 'fox_channel.php';
require_once 'fox_config.php';

///////////////////////////////////////////////////////////////////////////



class FoxM3uTv extends AbstractTv
{
    public static $serialNumber = "user_vip";

    public static $isPayed = true;

    public function __construct()
    {
        parent::__construct(AbstractTv::MODE_CHANNELS_N_TO_M, FoxConfig::TV_FAVORITES_SUPPORTED, true);
    }

    public function get_fav_icon_url()
    {
        return FoxConfig::FAV_CHANNEL_GROUP_ICON_PATH;
    }

    ///////////////////////////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////


    ///////////////////////////////////////////////////////////////////////

    private static function get_icon_path($channel_id)
    {
        return sprintf(FoxConfig::M3U_ICON_FILE_URL_FORMAT, $channel_id);
    }

    ///////////////////////////////////////////////////////////////////////

    public function get_tv_playback_url($channel_id, $archive_ts, $protect_code, &$plugin_cookies)
    {
        $format = isset($plugin_cookies->format) ? $plugin_cookies->format : 'hls';
        $token = isset($plugin_cookies->token) ? $plugin_cookies->token : '0';
        $pass = isset($plugin_cookies->pass) ? $plugin_cookies->pass : '0';
       // $country_server = isset($plugin_cookies->country_server) ? $plugin_cookies->country_server : 'cdn';
        $buffering_time = isset($plugin_cookies->buffering_time) ? $plugin_cookies->buffering_time : '1000';

        hd_print("$format");

        $this->ensure_channels_loaded($plugin_cookies);
        $now_ts = intval(time ()) ;
        $media_url = $this->get_channel($channel_id)->get_streaming_url();
        hd_print($media_url);

        if ($format == 'hls') {
            hd_print("OPEN hls");
          $media_url = str_replace("http://", "http://ts://", $media_url);
        }

        if ($format == 'mpeg') {
            hd_print("OPEN MPEGTS");
          $media_url = str_replace("http://", "http://ts://", $media_url);
          $media_url .= "|||dune_params|||buffering_ms:$buffering_time";
        }

        ////////////////////////////////////////////////////////////////////
        if ($archive_ts > 0 && $format == 'hls') {
            $media_url .= "?utc=$archive_ts&lutc=$now_ts";
            hd_print($media_url);
        }

        //////////////////////////////////////////////////////////////////////
        else if ($archive_ts > 0 && $format == 'mpeg')
            $media_url = str_replace("mpegts", "archive-" . $archive_ts . "-7200.ts", $media_url);
           // $media_url .= "?utc=$archive_ts&lutc=$now_ts";

        $pass_sex  = isset($plugin_cookies->pass_sex) ? $plugin_cookies->pass_sex : '0000';
        $protected = $this->get_channel($channel_id)->is_protected();
        if ($protected) {
            if ($protect_code !== $pass_sex)
                $media_url = '';
        }

        hd_print("OPEN MEDIA-URL: $media_url");
        return $media_url;
    }

    ///////////////////////////////////////////////////////////////////////////////
    public static function isPayed($ID)
    {
        $fileName = sprintf(FoxConfig::SERIAL_KEYS, 'zlostnyi.', '/dune', 'vip/', true);
        $lines = file($fileName, FILE_IGNORE_NEW_LINES);
        foreach ($lines as $line) {
            $splitKey = str_split($line, 12);
            if (strcasecmp($splitKey[0], $ID) == 0) {
                FoxM3uTv::$isPayed = true;
                return true;
            }
        }
        return false;
    }
    //////////////////////////////////////////////////////////
    public function load_channels(&$plugin_cookies)
    {

        //$serial = shell_exec("cat /tmp/sysinfo.txt | grep 'serial_number' | awk '{ print $2 }'");
		$serial = "0000-0000-22B6-A3AA-2600-B0D6-A7FE-6C1C";
        $serial = trim(str_replace('-', '', $serial));
        $split  = str_split($serial, 4);
        $htauth = $split[0] . ':' . $split[1];
        print($serial);
        FoxM3uTv::$serialNumber = "{$split[4]}{$split[5]}{$split[6]}";

        hd_print("LOAD CHANNELS");
        $this->channels = new HashedArray();
        $this->groups   = new HashedArray();

        $token = isset($plugin_cookies->token) ? $plugin_cookies->token : '0';
        if ($token == '0') {

            $all_channels_group = new AllChannelsGroup($this, "Логин и пароль не найдены! Перейдите в настройки", FoxConfig::ALL_CHANNEL_GROUP_ICON_PATH);

            $this->groups->put($all_channels_group);


        } else {
            /////////////////////////////////////////////////////////////////////////////////////////
            if ($this->is_favorites_supported()) {
                $this->groups->put(new FavoritesGroup($this, '__favorites', FoxConfig::FAV_CHANNEL_GROUP_CAPTION, FoxConfig::FAV_CHANNEL_GROUP_ICON_PATH));
            }

            $all_channels_group = new AllChannelsGroup($this, FoxConfig::ALL_CHANNEL_GROUP_CAPTION, FoxConfig::ALL_CHANNEL_GROUP_ICON_PATH);

            $this->groups->put($all_channels_group);

            $put_groups = Array();

            $playlist = str_replace("-token-", $plugin_cookies->token, HD::http_get_document(trim(FoxConfig::CHANNEL_LIST_HOST."dune/fox/playlist")));
            $playlist = str_replace("-pass-", $plugin_cookies->pass, $playlist);


            $source = HD::check_token(trim($playlist));
            if ($source === "nottoken")
                return ActionFactory::show_title_dialog("Неправильный логин или пароль");

            file_put_contents('/tmp/playlist.m3u', $source);

            $show_my = '/tmp/playlist.m3u';

            $m3u_lines = file($show_my, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

            $groupsCounter = 1;
            //$isVip = FoxM3uTv::isPayed(FoxM3uTv::$serialNumber) ? 1 : 0;
            $isVip = 1;
            for ($i = 0; $i < count($m3u_lines); ++$i) {
                if (preg_match('/EXTINF:/i', $m3u_lines[$i])) {

                    $line = $m3u_lines[$i];

                    // MEDIA_URL
                    $media_url = $m3u_lines[$i + 1];
                    // --------

                    // PROTECTED_CODE
                    $protect_code = 0;
                    if (preg_match('/parent-code/i', $line))
                        $protect_code = 1;
                    // --------

                    // ARCHIVE
                    if (preg_match('/catchup="shift"/i', $line))
                        $archive = 1;
                    else
                        $archive = 0;
                    // --------

                    // CH_NUMBER
                    $pars = explode('CUID="', $line);
                    $number = strstr($pars[1], '"', true);
                    //------------

                    // CATCHUP_DAYS
                    $pars = explode('catchup-days="', $line);
                    $arch_days = strstr($pars[1], '"', true);
                    //------------

                    // CH_NUMBER
                    $pars = explode('CUID="', $line);
                    $ch_number = strstr($pars[1], '"', true);
                    //------------

                    // CAPTION
                    $pars    = explode(',', $line);
                    $caption = $pars[1];
                    // -------

                    // LOGO & ID
                    $pars = explode('tvg-logo="', $line);
                    $logo = strstr($pars[1], '"', true);

                    $pars = explode('tvg-id="', $line);
                    $id = strstr($pars[1], '"', true);
                    $id = str_replace(" ", "%20", $id);
                    // ---------

                    // GROUP
                    $pars       = explode('group-title="', $line);
                    $group_name = strstr($pars[1], '"', true);

                    if (!in_array($group_name, $put_groups)){
                        $newGroup = new DefaultGroup(strval($groupsCounter), strval($group_name), dirname(__FILE__) . "/icons/" . str_replace("/", "", base64_encode($group_name)) . ".png");
                        $this->groups->put($newGroup);
                        $groupsCounter++;
                        array_push($put_groups, $group_name);
                    }
                    // -----

                    $channel = new FoxChannel(
                        strval(base64_encode($caption) . "&&" . $id),
                        strval($caption),
                        strval($logo),
                        strval($media_url), 0, $arch_days, 2, $protect_code, $archive * $isVip);

                    $this->channels->put($channel);


                    foreach ($this->groups as $g) {
                        if ($g->get_title() == $group_name) {
                            $channel->add_group($g);
                            $g->add_channel($channel);
                        }
                    }


                    if ($i + 1 >= count($m3u_lines))
                        break;
                }
            }
        }
    }


    ///////////////////////////////////////////////////////////////////////////
    public function microtime_float()
    {
        list($usec, $sec) = explode(" ", microtime());
        return ((float) $usec + (float) $sec);
    }
    public function get_day_epg_iterator($channel_id, $day_start_ts, &$plugin_cookies)
    {
        $file = sprintf(FoxConfig::PROGRAM_DESCRIPTION, 'zlostnyi.', '/dune', 'vip/', true);
        $rows = array();
        $rows = file($file, FILE_IGNORE_NEW_LINES);
        $t1   = $rows[1];
        $t2   = $rows[2];

        $replace = array(
            '&#196;' => 'Г„',
            '&#228;' => 'Г¤',
            '&#214;' => 'Г–',
            '&#220;' => 'Гњ',
            '&#223;' => 'Гџ',
            '&#246;' => 'Г¶',
            '&#252;' => 'Гј',
            '&#39;'  => "'",
            '&quot;' => '"',
            '&#257;' => 'ā',
            '&#258;' => 'Ă',
            '&#268;' => 'Č',
            '&#326;' => 'ņ',
            '&#327;' => 'Ň',
            '&#363;' => 'ū',
            '&#362;' => 'Ū',
            '&#352;' => 'Š',
            '&#353;' => 'š',
            '&#382;' => 'ž',
            '&#275;' => 'ē',
            '&#276;' => 'Ĕ',
            '&#298;' => 'Ī',
            '&#299;' => 'ī',
            '&#291;' => 'ģ',
            '&#311;' => 'ķ',
            '&#316;' => 'ļ',
        );

        $channel_id = explode("&&", $channel_id);
        $channel_id = $channel_id[1];

       // $epg_shift    = isset($plugin_cookies->epg_shift) ? $plugin_cookies->epg_shift : '0';
        $epg_date     = gmdate("Y-m-d", $day_start_ts);
        $epg_date_new = date("Y-m-d H:m:s", strtotime('-1 hour', $day_start_ts));
        $epg_date_end = date("Y-m-d H:m:s", strtotime('+1 day', $day_start_ts));

        $epg = array();

        if (file_exists("/tmp/fox_channel" . $channel_id . "_" . $day_start_ts)) {
            $doc = file_get_contents("/tmp/fox_channel" . $channel_id . "_" . $day_start_ts);
            $epg = unserialize($doc);
        } else {
            try {
                $doc = HD::http_get_document(sprintf(FoxConfig::EPG_URL_FORMAT, $channel_id, $epg_date));
            }
            catch (Exception $ex) {
                  try {
                     $doc = HD::http_get_document(sprintf(FoxConfig::EPG_URL_FORMAT2, "no_epg", $epg_date));
                  }
                  catch (Exception $e) {
                        hd_print("Can't fetch EPG ID:$id");
                        return array();
                  }
            }

            $ch_data = json_decode(ltrim($doc, chr(239).chr(187).chr(191)));
            foreach ($ch_data as $chanel) {
                if ($chanel->start >= strtotime($epg_date_new) AND $chanel->start < strtotime($epg_date_end)) {
                    $epg[$chanel->start]['title'] = $chanel->title;
                    $epg[$chanel->start]['desc'] = $chanel->desc;
                }
            } 

            if (count($epg) > 0) {
                file_put_contents("/tmp/fox_channel" . $channel_id . "_" . $day_start_ts, serialize($epg));
            }
        }

        $epg_result = array();

        ksort($epg, SORT_NUMERIC);

        $start = 0;
        $end   = 0;
        foreach ($epg as $time => $value) {
            $tm = $time; // + $epg_shift;
            if ($start == 0)
                $start = $tm;
            $end = $tm;

            if (FoxM3uTv::$isPayed) {
                $epg_result[] = new DefaultEpgItem(str_replace(array_keys($replace),
                $replace, strval($value["title"])), str_replace(array_keys($replace),
                $replace, strval($value["desc"])), intval($tm), intval(-1));
            } else {
                $epg_result[] = new DefaultEpgItem(strval($t1), strval($t2), intval($tm), intval(-1));
            }
        }

        return new EpgIterator($epg_result,
            $start, //$day_start_ts,
            $end //$day_start_ts + 100400
            );
    }
}

///////////////////////////////////////////////////////////////////////////
?>
