﻿<?php
///////////////////////////////////////////////////////////////////////////
require_once 'lib/abstract_preloaded_regular_screen.php';
require_once 'lib/abstract_controls_screen.php';
require_once 'fox_m3u_tv.php';

///////////////////////////////////////////////////////////////////////////

class FoxSetupScreen extends AbstractControlsScreen
{
    const ID = 'setup';
    ///////////////////////////////////////////////////////////////////////
    public static function get_media_url_str()
    {
        return MediaURL::encode(array(
            'screen_id' => self::ID
        ));
    }
    protected $tv;
    public function __construct(Tv $tv)
    {
        parent::__construct(self::ID);
        $this->tv = $tv;
    }

    public function do_get_control_defs(&$plugin_cookies)
    {
        $defs = array();

        $show_tv        = isset($plugin_cookies->show_tv) ? $plugin_cookies->show_tv : 'yes';
        $format         = isset($plugin_cookies->format) ? $plugin_cookies->format : 'hls';
        $show_icons     = isset($plugin_cookies->show_icons) ? $plugin_cookies->show_icons : '/D/';
      //  $epg_shift      = isset($plugin_cookies->epg_shift) ? $plugin_cookies->epg_shift : '0';
        $epg_font_size  = isset($plugin_cookies->epg_font_size) ? $plugin_cookies->epg_font_size : 'SMALL';
        $token          = isset($plugin_cookies->token) ? $plugin_cookies->token : '0';
        $pass           = isset($plugin_cookies->pass) ? $plugin_cookies->pass : '0';
        $buffering_time = isset($plugin_cookies->buffering_time) ? $plugin_cookies->buffering_time : '1000';
        $pass_sex       = isset($plugin_cookies->pass_sex) ? $plugin_cookies->pass_sex : '0000';
        $country_server = isset($plugin_cookies->country_server) ? $plugin_cookies->country_server : 'cdn';


        //$serial = shell_exec("cat /tmp/sysinfo.txt | grep 'serial_number' | awk '{ print $2 }'");
		$serial = "0000-0000-22B6-A3AA-2600-B0D6-A7FE-6C1C";
        $serial = trim(str_replace('-', '', $serial));
        $split  = str_split($serial, 4);
        $htauth = $split[0] . ':' . $split[1];
        print($serial);
        FoxM3uTv::$serialNumber = "{$split[4]}{$split[5]}{$split[6]}";
        /////////////////////////////////////////////////////////////////////////
        for ($i = -12; $i < 13; $i++)
            $shift_ops[$i * 3600] = $i;

        ControlFactory::add_vgap($defs, -10);
      //  $show_ops        = array();
      //  $show_ops['yes'] = 'Да';
      //  $show_ops['no']  = 'Нет';

        $show_my = isset($plugin_cookies->show_my) ? $plugin_cookies->show_my : dirname(__FILE__) . '/playlist.m3u';

        $this->add_label($defs, 'Fox TV', 'Версия ' . FoxConfig::PluginVersion . '. [' . FoxConfig::PluginDate . ']');
        $this->add_label($defs, 'Код для VIP-статуса: ', '' . FoxM3uTv::$serialNumber . 'Z');
        $this->add_button($defs, 'edit_token', 'Активировать просмотр:', 'Введите логин и пароль', 0);
      //  $this->add_combobox($defs, 'show_tv', 'Отображать в ТВ:', $show_tv, $show_ops, 0, true);

       // $server_ops = array();
       //     $server_ops['cdn'] = 'Frankfurt ';
       //     $server_ops['st'] = 'Stockholm ';
       //     $server_ops['mow'] = 'Moscow ';
       // $this->add_combobox($defs,
       //     'country_server', 'Выбор сервера:',
       //     $country_server, $server_ops, 0, true);


       // $format_ops                        = array();
       // $format_ops['hls']                 = 'HLS';
       // $format_ops['mpeg']                = 'MPEG-TS';
       // $this->add_combobox($defs, 'format', 'Выбор потока:', $format, $format_ops, 0, true);

     //   $this->add_combobox($defs, 'epg_shift', 'Коррекция программы (час):', $epg_shift, $shift_ops, 0, true);

        $buffering_ops          = array();
        $buffering_ops['500']   = '500';
        $buffering_ops['1000']  = '1000 (по умолчанию)';
        $buffering_ops['1500']  = '1500';
        $buffering_ops['2000']  = '2000';
        $buffering_ops['2500']  = '2500';
        $buffering_ops['3000']  = '3000';
        $buffering_ops['4000']  = '4000';
        $buffering_ops['5000']  = '5000';
        $buffering_ops['6000']  = '6000';
        $buffering_ops['8000']  = '8000';
        $buffering_ops['10000'] = '10000';
        $buffering_ops['15000'] = '15000';
        $buffering_ops['20000'] = '20000';
        $buffering_ops['25000'] = '25000';
        $buffering_ops['30000'] = '30000';
        $buffering_ops['35000'] = '35000';
        $buffering_ops['45000'] = '45000';
        $buffering_ops['50000'] = '50000';

        $this->add_combobox($defs, 'buffering_time', 'Время буферизации:', $buffering_time, $buffering_ops, 0, true);

        $epg_font_size_ops           = array();
        $epg_font_size_ops['NORMAL'] = 'Обычный';
        $epg_font_size_ops['SMALL']  = 'Мелкий';

        $this->add_combobox($defs, 'epg_font_size', 'Размер шрифта EPG:', $epg_font_size, $epg_font_size_ops, 0, true);

        //////////////////////////////////////////////////////////////////////////
        $my_dir_ops = array();

        $my_dir_ops[dirname(__FILE__) . '/playlist.m3u'] = dirname(__FILE__) . '/playlist.m3u';

        foreach (glob('/D/*.m3u') as $file) {
            //hd_print("-------$file");
            if (strlen($file) > 36)
                $ur = substr($file, -30);
            else
                $ur = $file;
            $my_dir_ops[$file] = $ur;
            //hd_print("-------$file");
        }

        $my_dir_icons = array();


        foreach (glob('/D/*') as $file) {
            $my_dir_icons[$file] = $file;
            //hd_print("-------$file");
        }

        $this->add_button($defs, 'pass_dialog', 'Пароль для взрослых каналов:', 'Изменить пароль', 0);
        $this->add_button($defs, ' ', 'Разработка плагина:', 'Zло©тный http://zlostnyi.tech', 0);
        //       $this->add_label($defs, 'Информация --------------------------------','-----------------------------');
        ControlFactory::add_vgap($defs, -10);
        return $defs;
    }

    public function get_control_defs(MediaURL $media_url, &$plugin_cookies)
    {
        return $this->do_get_control_defs($plugin_cookies);
    }

    public function do_get_pass_control_defs(&$plugin_cookies)
    {
        $defs = array();

        $pass1 = '';
        $pass2 = '';

        $this->add_text_field($defs, 'pass1', 'Старый пароль:', $pass1, 1, 1, 0, 1, 500, 0, false);
        $this->add_text_field($defs, 'pass2', 'Новый пароль:', $pass2, 1, 1, 0, 1, 500, 0, false);

        $this->add_label($defs, '', '');

        $this->add_close_dialog_and_apply_button($defs, 'pass_apply', 'ОК', 250);
        $this->add_close_dialog_button($defs, 'Отмена', 250);

        return $defs;
    }

    public function handle_user_input(&$user_input, &$plugin_cookies)
    {
        hd_print('Setup: handle_user_input:');
        foreach ($user_input as $key => $value)
            hd_print("  $key => $value");

        if ($user_input->control_id === 'edit_token')
            return $this->do_get_edit_pcode_action(&$plugin_cookies);

        else if ($user_input->control_id === 'pcode') {

            $plugin_cookies->token = $user_input->current_token;
            $plugin_cookies->pass = $user_input->current_pass;
            $playlist = str_replace("-token-", $plugin_cookies->token, HD::http_get_document(trim(FoxConfig::CHANNEL_LIST_HOST."dune/fox/playlist")));
            $playlist = str_replace("-pass-", $plugin_cookies->pass, $playlist);

            hd_print($playlist);

            $source  = HD::check_token(trim($playlist));

            $this->tv->unload_channels();
            $this->tv->load_channels(&$plugin_cookies);

            if ($source === "nottoken" || $source == "")
                return ActionFactory::show_title_dialog("Неправильный логин или пароль");


            $perform_new_action = UserInputHandlerRegistry::create_action($this, 'reset_controls');
            return ActionFactory::close_dialog_and_run(ActionFactory::invalidate_folders(array(
                'tv_group_list'
            ), $perform_new_action));
        }

        else if ($user_input->action_type === 'confirm' || $user_input->action_type === 'apply') {
            $control_id = $user_input->control_id;
            $new_value  = $user_input->{$control_id};
            hd_print("Setup: changing $control_id value to $new_value");

            if ($control_id === 'show_tv')
                $plugin_cookies->show_tv = $new_value;
          //  else if ($control_id === 'epg_shift')
          //      $plugin_cookies->epg_shift = $new_value;

            else if ($control_id === 'dev'){
                $plugin_cookies->dev = $new_value;
                $this->tv->unload_channels();
                $this->tv->load_channels(&$plugin_cookies);
                $perform_new_action = UserInputHandlerRegistry::create_action($this, 'reset_controls');
                return ActionFactory::invalidate_folders(array(
                    'tv_group_list'
                ), $perform_new_action);
            }
            else if ($control_id === 'format') {
                if ($new_value === 'hlsffmpeg') {
                    $test = file_get_contents("http://127.0.0.1:81/cgi-bin/hls.sh");
                if (!$test)
                        return ActionFactory::show_title_dialog("Кодеки не найдены");
                else
                        $plugin_cookies->format = $new_value;
            } else
                    $plugin_cookies->format = $new_value;
            } else if ($control_id === 'epg_font_size')
                $plugin_cookies->epg_font_size = $new_value;
            else if ($control_id == 'buffering_time')
                $plugin_cookies->buffering_time = $new_value;
            else if ($control_id === 'country_server')
                $plugin_cookies->country_server = $new_value;
            else if ($control_id === 'show_icons')
                $plugin_cookies->show_icons = $new_value;
            else if ($control_id === 'show_my') {

                $plugin_cookies->show_my = $new_value;
                $this->tv->unload_channels();
                $this->tv->load_channels(&$plugin_cookies);
                $perform_new_action = UserInputHandlerRegistry::create_action($this, 'reset_controls');
                return ActionFactory::invalidate_folders(array(
                    'tv_group_list'
                ), $perform_new_action);
            }


            else if ($control_id === 'pass_dialog') {
                $defs = $this->do_get_pass_control_defs($plugin_cookies);

                return ActionFactory::show_dialog("Родительский контроль", $defs, true);
            } else if ($control_id === 'pass_apply') {
                if ($user_input->pass1 == '' || $user_input->pass2 == '')
                    return null;
                $msg      = '';
                $action   = null;
                $pass_sex = isset($plugin_cookies->pass_sex) ? $plugin_cookies->pass_sex : '0000';
                if ($user_input->pass1 == $pass_sex) {
                    $plugin_cookies->pass_sex = $user_input->{'pass2'};
                    $msg                      = 'Пароль изменен!';
                } else {
                    $msg = 'Пароль не изменен!';
                }

                return ActionFactory::show_title_dialog($msg, $action);
            }
        }

        return ActionFactory::reset_controls($this->do_get_control_defs($plugin_cookies));
    }
    private function do_get_edit_pcode_defs(&$plugin_cookies)
    {
        $defs = array();

        $this->add_text_field($defs, 'current_token', 'Логин:', $plugin_cookies->token,  false, false, false, true, 500);
        $this->add_text_field($defs, 'current_pass', 'Пароль:', $plugin_cookies->pass,  false, false, false, true, 500);

        $this->add_vgap($defs, 50);

        $this->add_button($defs, 'pcode', null, 'Применить', 300);
        $this->add_close_dialog_button($defs,'Отмена', 300);


        return $defs;
    }

    private function do_get_edit_pcode_action(&$plugin_cookies)
    {
        return ActionFactory::show_dialog('Введите логин и пароль', $this->do_get_edit_pcode_defs(&$plugin_cookies), true);
    }
}

///////////////////////////////////////////////////////////////////////////
?>
