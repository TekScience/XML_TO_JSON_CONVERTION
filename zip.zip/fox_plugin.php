﻿<?php
///////////////////////////////////////////////////////////////////////////

require_once 'lib/default_dune_plugin.php';
require_once 'lib/utils.php';

require_once 'lib/tv/tv_group_list_screen.php';
require_once 'lib/tv/tv_favorites_screen.php';

require_once 'lib/vod/vod_list_screen.php';
require_once 'lib/vod/vod_movie_screen.php';
require_once 'lib/vod/vod_series_list_screen.php';
require_once 'lib/vod/vod_favorites_screen.php';

require_once 'fox_config.php';

require_once 'fox_tv.php';
require_once 'fox_m3u_tv.php';
require_once 'fox_vod.php';
require_once 'fox_setup_screen.php';
require_once 'fox_tv_channel_list_screen.php';
require_once 'fox_vod_category_list_screen.php';
require_once 'fox_vod_list_screen.php';
require_once 'fox_main_screen.php';

///////////////////////////////////////////////////////////////////////////

class FoxPlugin extends DefaultDunePlugin
{
    public function __construct()
    {
        $this->tv =
            FoxConfig::USE_M3U_FILE ?
            new FoxM3uTv() :
            new FoxTv();

        $this->vod = new FoxVod();

        if (FoxConfig::USE_M3U_FILE)
        {
            //$this->add_screen(new TvGroupListScreen($this->tv,
            //        FoxConfig::GET_TV_GROUP_LIST_FOLDER_VIEWS()));
            $this->add_screen(new Fox_MainScreen($this->tv,
                FoxConfig::GET_TV_GROUP_LIST_FOLDER_VIEWS()));
        }

        $this->add_screen(new FoxTvChannelListScreen($this->tv,
                FoxConfig::GET_TV_CHANNEL_LIST_FOLDER_VIEWS()));
        $this->add_screen(new TvFavoritesScreen($this->tv,
                FoxConfig::GET_TV_CHANNEL_LIST_FOLDER_VIEWS()));

        $this->add_screen(new FoxSetupScreen($this->tv,
                FoxConfig::GET_TV_CHANNEL_LIST_FOLDER_VIEWS()));
				
        $this->add_screen(new VodFavoritesScreen($this->vod));
        $this->add_screen(new FoxVodCategoryListScreen());
        $this->add_screen(new FoxVodListScreen($this->vod));
        $this->add_screen(new VodMovieScreen($this->vod));
        $this->add_screen(new VodSeriesListScreen($this->vod));
    }
}

///////////////////////////////////////////////////////////////////////////
?>
